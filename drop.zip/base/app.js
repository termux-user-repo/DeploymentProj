(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const ui = {
    stage: $("stage"),
    empty: $("empty"),
    browser: $("browser"),
    frame: $("frame"),
    address: $("address"),
    tabs: $("tabs"),
    pickFiles: $("pick-files"),
    pickFolder: $("pick-folder"),
    fileInput: $("file-input"),
    dirInput: $("dir-input"),
    list: $("files"),
    count: $("count"),
    clear: $("clear"),
    download: $("download"),
    error: $("error"),
  };

  let queue = [];          // [{ path, file }]
  let activePage = "index.html";
  let siteName = "site";
  let buildToken = 0;

  // Helpers

  const formatBytes = (n) =>
    n < 1024 ? `${n} B`
    : n < 1048576 ? `${(n / 1024).toFixed(1)} KB`
    : `${(n / 1048576).toFixed(1)} MB`;

  const totalBytes = () => queue.reduce((sum, e) => sum + e.file.size, 0);
  const isHtml = (p) => /\.html?$/i.test(p);
  const hasIndex = () => queue.some((e) => e.path === "index.html");
  const findEntry = (path) => queue.find((e) => e.path === path) || null;

  // Skip .DS_Store, .git, and other dotfiles or dot-folders.
  const isJunk = (p) => p.split("/").some((seg) => seg.startsWith("."));

  // If everything sits in one wrapper folder, drop it so that
  // "my-site/index.html" becomes "index.html".
  function stripCommonRoot(entries) {
    if (entries.length === 0) return entries;
    const roots = new Set(entries.map((e) => e.path.split("/")[0]));
    const allNested = entries.every((e) => e.path.includes("/"));
    if (allNested && roots.size === 1) {
      return entries.map((e) => ({ ...e, path: e.path.slice(e.path.indexOf("/") + 1) }));
    }
    return entries;
  }

  function addEntries(entries) {
    const kept = stripCommonRoot(entries.filter((e) => !isJunk(e.path)));
    const byPath = new Map(queue.map((e) => [e.path, e]));
    for (const e of kept) byPath.set(e.path, e); // same path replaces the old file
    queue = [...byPath.values()].sort((a, b) => a.path.localeCompare(b.path));
    render();
  }

  // Resolve a link or asset reference relative to the page that contains it.
  function resolvePath(fromPath, href) {
    try {
      const base = new URL("http://site.local/" + fromPath);
      const url = new URL(href, base);
      if (url.origin !== base.origin) return null;
      return decodeURIComponent(url.pathname).replace(/^\//, "");
    } catch {
      return null;
    }
  }

  const entryAt = (fromPath, href) => {
    const p = resolvePath(fromPath, href);
    return p ? findEntry(p) : null;
  };

  const pages = () =>
    queue
      .map((e) => e.path)
      .filter(isHtml)
      .sort((a, b) => (a === "index.html" ? -1 : b === "index.html" ? 1 : a.localeCompare(b)));

  function readAsDataUrl(file) {
    return new Promise((res, rej) => {
      const reader = new FileReader();
      reader.onload = () => res(reader.result);
      reader.onerror = () => rej(reader.error);
      reader.readAsDataURL(file);
    });
  }

  // Preview builder: inlines local CSS and JS, and turns local images
  // and CSS url() references into data URLs, so the page runs in one
  // sandboxed document without a server.

  async function inlineCssUrls(css, cssPath) {
    let out = css;
    for (const m of [...css.matchAll(/url\(\s*(['"]?)([^'")\s]+)\1\s*\)/g)]) {
      const e = entryAt(cssPath, m[2]);
      if (!e) continue;
      out = out.split(m[0]).join(`url("${await readAsDataUrl(e.file)}")`);
    }
    return out;
  }

  async function buildPreview(pagePath) {
    const page = findEntry(pagePath);
    const doc = new DOMParser().parseFromString(await page.file.text(), "text/html");

    for (const link of doc.querySelectorAll('link[rel~="stylesheet"][href]')) {
      const e = entryAt(pagePath, link.getAttribute("href"));
      if (!e) continue;
      const style = doc.createElement("style");
      style.textContent = await inlineCssUrls(await e.file.text(), e.path);
      link.replaceWith(style);
    }

    for (const script of doc.querySelectorAll("script[src]")) {
      const e = entryAt(pagePath, script.getAttribute("src"));
      if (!e) continue;
      const inline = doc.createElement("script");
      inline.textContent = (await e.file.text()).replace(/<\/script/gi, "<\\/script");
      script.replaceWith(inline);
    }

    const assetSelector =
      "img[src], source[src], video[src], audio[src], video[poster], link[rel~='icon'][href]";
    for (const el of doc.querySelectorAll(assetSelector)) {
      const attr = el.hasAttribute("src") ? "src" : el.hasAttribute("poster") ? "poster" : "href";
      const e = entryAt(pagePath, el.getAttribute(attr));
      if (e) el.setAttribute(attr, await readAsDataUrl(e.file));
    }

    // Links to other pages in the site navigate inside the preview.
    for (const a of doc.querySelectorAll("a[href]")) {
      const href = a.getAttribute("href");
      if (href.startsWith("#")) continue;
      const e = entryAt(pagePath, href);
      if (e && isHtml(e.path)) {
        a.dataset.page = e.path;
        a.setAttribute("href", "#");
      }
    }

    const bridge = doc.createElement("script");
    bridge.textContent =
      'document.addEventListener("click",function(e){' +
      'var a=e.target.closest&&e.target.closest("a[data-page]");' +
      'if(!a)return;e.preventDefault();' +
      'parent.postMessage({dropPage:a.dataset.page},"*");});';
    doc.body.append(bridge);

    return "<!DOCTYPE html>\n" + doc.documentElement.outerHTML;
  }

  // Rendering

  function renderList() {
    ui.list.replaceChildren(
      ...queue.map((entry, i) => {
        const li = document.createElement("li");
        if (isHtml(entry.path)) li.classList.add("is-page");

        const name = document.createElement("span");
        name.className = "name";
        name.textContent = entry.path;

        const meta = document.createElement("span");
        meta.className = "meta";
        const size = document.createElement("span");
        size.textContent = formatBytes(entry.file.size);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "link";
        remove.textContent = "Remove";
        remove.setAttribute("aria-label", `Remove ${entry.path}`);
        remove.addEventListener("click", () => {
          queue.splice(i, 1);
          render();
        });

        meta.append(size, remove);
        li.append(name, meta);
        return li;
      })
    );
  }

  function renderTabs(list) {
    ui.tabs.replaceChildren(
      ...list.map((path) => {
        const tab = document.createElement("button");
        tab.type = "button";
        tab.className = "tab";
        tab.setAttribute("role", "tab");
        tab.setAttribute("aria-selected", String(path === activePage));
        tab.textContent = path;
        tab.addEventListener("click", () => showPage(path));
        return tab;
      })
    );
  }

  async function showPage(path) {
    activePage = path;
    const list = pages();
    renderTabs(list);
    ui.address.textContent = `${siteName}/${path}`;

    const token = ++buildToken;
    const html = await buildPreview(path);
    if (token === buildToken) ui.frame.srcdoc = html;
  }

  function refreshPreview() {
    const list = pages();
    if (queue.length === 0) return;
    if (list.length === 0) {
      renderTabs([]);
      ui.address.textContent = `${siteName}/`;
      ui.frame.srcdoc =
        '<p style="font:16px/1.5 system-ui,sans-serif;color:#6C665A;padding:2rem">' +
        "No HTML pages in this site yet.</p>";
      return;
    }
    if (!list.includes(activePage)) activePage = list[0];
    showPage(activePage);
  }

  function render() {
    const has = queue.length > 0;
    const n = queue.length;

    ui.count.textContent = has
      ? `${n} file${n === 1 ? "" : "s"}, ${formatBytes(totalBytes())}`
      : "No files yet";
    ui.clear.hidden = !has;
    ui.download.disabled = !hasIndex();
    ui.empty.hidden = has;
    ui.browser.hidden = !has;
    ui.error.textContent = has && !hasIndex()
      ? "There's no index.html at the top level yet. Add one so the site has a home page."
      : "";

    renderList();
    refreshPreview();
  }

  // Zip (store only, no compression)

  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  function buildZip(entries) {
    const enc = new TextEncoder();
    const now = new Date();
    const dosDate =
      ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);

    const parts = [];
    const central = [];
    let offset = 0;

    for (const { name, data } of entries) {
      const nameBytes = enc.encode(name);
      const crc = crc32(data);
      const size = data.length;

      const local = new DataView(new ArrayBuffer(30));
      local.setUint32(0, 0x04034b50, true);
      local.setUint16(4, 20, true);
      local.setUint16(6, 0x0800, true); // UTF-8 names
      local.setUint16(8, 0, true);      // stored, no compression
      local.setUint16(10, dosTime, true);
      local.setUint16(12, dosDate, true);
      local.setUint32(14, crc, true);
      local.setUint32(18, size, true);
      local.setUint32(22, size, true);
      local.setUint16(26, nameBytes.length, true);
      local.setUint16(28, 0, true);
      parts.push(local, nameBytes, data);

      const cen = new DataView(new ArrayBuffer(46));
      cen.setUint32(0, 0x02014b50, true);
      cen.setUint16(4, 20, true);
      cen.setUint16(6, 20, true);
      cen.setUint16(8, 0x0800, true);
      cen.setUint16(10, 0, true);
      cen.setUint16(12, dosTime, true);
      cen.setUint16(14, dosDate, true);
      cen.setUint32(16, crc, true);
      cen.setUint32(20, size, true);
      cen.setUint32(24, size, true);
      cen.setUint16(28, nameBytes.length, true);
      cen.setUint32(42, offset, true);
      central.push(cen, nameBytes);

      offset += 30 + nameBytes.length + size;
    }

    const cenSize = central.reduce((s, p) => s + p.byteLength, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, entries.length, true);
    end.setUint16(10, entries.length, true);
    end.setUint32(12, cenSize, true);
    end.setUint32(16, offset, true);

    return new Blob([...parts, ...central, end], { type: "application/zip" });
  }

  async function downloadZip() {
    if (!hasIndex()) {
      ui.error.textContent = "Add an index.html at the top level before you download.";
      return;
    }
    ui.download.disabled = true;
    ui.download.textContent = "Packing…";
    try {
      const entries = await Promise.all(
        queue.map(async (e) => ({ name: e.path, data: new Uint8Array(await e.file.arrayBuffer()) }))
      );
      const url = URL.createObjectURL(buildZip(entries));
      const a = document.createElement("a");
      a.href = url;
      a.download = `${siteName}.zip`;
      document.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      ui.error.textContent = "Something went wrong packing the files. Try again.";
    } finally {
      ui.download.textContent = "Download zip";
      ui.download.disabled = !hasIndex();
    }
  }

  // Folder reading for drag and drop

  async function readEntry(entry, prefix) {
    if (entry.isFile) {
      const file = await new Promise((res, rej) => entry.file(res, rej));
      return [{ path: prefix + entry.name, file }];
    }
    const reader = entry.createReader();
    const children = [];
    let batch;
    do {
      batch = await new Promise((res, rej) => reader.readEntries(res, rej));
      children.push(...batch);
    } while (batch.length > 0);
    const nested = await Promise.all(
      children.map((child) => readEntry(child, prefix + entry.name + "/"))
    );
    return nested.flat();
  }

  // Events

  ui.pickFiles.addEventListener("click", () => ui.fileInput.click());
  ui.pickFolder.addEventListener("click", () => ui.dirInput.click());

  ui.fileInput.addEventListener("change", () => {
    addEntries(Array.from(ui.fileInput.files, (f) => ({ path: f.name, file: f })));
    ui.fileInput.value = "";
  });

  ui.dirInput.addEventListener("change", () => {
    const files = Array.from(ui.dirInput.files);
    if (files.length && files[0].webkitRelativePath) {
      siteName = files[0].webkitRelativePath.split("/")[0] || siteName;
    }
    addEntries(files.map((f) => ({ path: f.webkitRelativePath || f.name, file: f })));
    ui.dirInput.value = "";
  });

  ui.clear.addEventListener("click", () => {
    queue = [];
    render();
  });
  ui.download.addEventListener("click", downloadZip);

  window.addEventListener("message", (e) => {
    if (e.source !== ui.frame.contentWindow) return;
    const target = e.data && e.data.dropPage;
    if (target && pages().includes(target)) showPage(target);
  });

  // Drop anywhere on the window.
  let dragDepth = 0;
  const hasFiles = (e) => Array.from((e.dataTransfer && e.dataTransfer.types) || []).includes("Files");

  document.addEventListener("dragenter", (e) => {
    if (!hasFiles(e)) return;
    dragDepth++;
    ui.stage.classList.add("is-over");
  });
  document.addEventListener("dragleave", () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) ui.stage.classList.remove("is-over");
  });
  document.addEventListener("dragover", (e) => e.preventDefault());
  document.addEventListener("drop", async (e) => {
    e.preventDefault();
    dragDepth = 0;
    ui.stage.classList.remove("is-over");

    const roots = Array.from(e.dataTransfer.items || [])
      .map((item) => (item.webkitGetAsEntry ? item.webkitGetAsEntry() : null))
      .filter(Boolean);

    if (roots.length) {
      const folderRoot = roots.find((r) => !r.isFile);
      if (roots.length === 1 && folderRoot) siteName = folderRoot.name;
      const nested = await Promise.all(roots.map((r) => readEntry(r, "")));
      addEntries(nested.flat());
    } else {
      addEntries(Array.from(e.dataTransfer.files, (f) => ({ path: f.name, file: f })));
    }
  });

  render();
})();
